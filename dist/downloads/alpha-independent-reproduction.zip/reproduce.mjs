import {readFile,writeFile} from 'node:fs/promises';
import {queryControl,readBundle} from './controlQuery.ts';
import {parseAssurance} from './assuranceData.ts';
const [input,output='reproduced-controls.json']=process.argv.slice(2);
if(!input){console.error('Usage: node --experimental-strip-types reproduce.mjs audit-bundle.json [output.json]');process.exit(2)}
try{const payload=await readBundle(JSON.parse(await readFile(input,'utf8')));const data=parseAssurance(payload.assurance);const evaluations=data.runs.flatMap(run=>['7','16'].map(control=>queryControl(run,control)));await writeFile(output,JSON.stringify({reproducedAt:new Date().toISOString(),algorithm:'alpha-query-v1',input,source:data.source,readAt:data.readAt,evaluations},null,2));console.log(`${data.runs.length} runs recomputed; ${evaluations.filter(e=>e.verdict==='PASS').length} passes, ${evaluations.filter(e=>e.verdict==='BREACH').length} breaches, ${evaluations.filter(e=>e.verdict==='INSUFFICIENT EVIDENCE').length} insufficient evidence. Output: ${output}`)}catch(e){console.error(e.message);process.exit(1)}
