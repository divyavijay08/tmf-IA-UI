Team Alpha trustworthy observability — offline verification

The active app is at http://localhost:5174/. The workspace covers observed agents and principals, executions, cross-run evidence, CloudWatch traces, controls, findings, notifications, ServiceNow sources, coverage and reproduction.

The genuine c16-breach-01 export contains 91,113 recorded tokens against 60,000. This saved evaluator result is distinct from independent evidence completeness or budget prevention. The original gateway/action per-call bijection is not proven.

Run offline: Node 22+ is required. No network is used by the checker.
  node --experimental-strip-types reproduce.mjs alpha-current-audit-bundle.json reproduced-controls.json

The bundle checksum protects the included bytes relative to the included checksum, not source authenticity. The checker recomputes records, rejects duplicate call IDs, requires prior threshold declarations and independent expected inventories, and retains the whole-run cap for window queries.

Current exported evidence produces 52 INSUFFICIENT EVIDENCE results over 26 runs. This is intentional: do not convert saved SATISFIED assessments into independently verified results by supplying retrospective inventories or thresholds.

Browser-verified ServiceNow: CISET0021161 / TH0026475. Transform Complete; zero total, processed, inserts and updates. HTTP 200 from CloudWatch is not proof of imported usage. SageMaker returned 400. Per-run ServiceNow and external notification delivery links still need source verification.
